# Products

Find products to recommend (Channel3 catalog).

```python
products_api = client.products
```

## Class Name

`ProductsApi`


# Search Products

Searches 100M+ products from 25k+ stores through Channel3. Pass a result's `id` to `createShop` with `source=channel3`.

:information_source: **Note** This endpoint does not require authentication.

```python
def search_products(self,
                   q)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `q` | `str` | Query, Required | What to look for, in plain words.<br><br>**Constraints**: *Maximum Length*: `200` |

## Response Type

**200**: Up to 12 products.

[`ApiChannel3SearchResponse`](../../doc/models/api-channel-3-search-response.md)

## Example Usage

```python
q = 'gifts for trail runners under $60'

result = products_api.search_products(q)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 502 | Gemini, PayPal or Channel3 failed or isn't configured. | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | Gemini, PayPal or Channel3 failed or isn't configured. | [`ErrorException`](../../doc/models/error-exception.md) |

