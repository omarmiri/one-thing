# Orders

The seller's orders, fulfilment and PayPal webhook log.

```python
orders_api = client.orders
```

## Class Name

`OrdersApi`

## Methods

* [List Orders](../../doc/controllers/orders.md#list-orders)
* [Mark Order Shipped](../../doc/controllers/orders.md#mark-order-shipped)
* [List Webhook Events](../../doc/controllers/orders.md#list-webhook-events)


# List Orders

Newest first. Checkouts that were never approved are left out.

```python
def list_orders(self,
               slug)
```

## Authentication

This endpoint requires [AdminToken](../../doc/auth/custom-header-signature.md) **OR** [PlatformKey](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `slug` | `str` | Template, Required | The shop's link name (current or former). |

## Response Type

**200**: Orders.

[`List[Order]`](../../doc/models/order.md)

## Example Usage

```python
slug = 'raptorrush'

result = orders_api.list_orders(slug)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | No such shop, or the admin token or API key doesn't match it. | [`ErrorException`](../../doc/models/error-exception.md) |


# Mark Order Shipped

Saves the tracking number and pushes it to PayPal, so the buyer sees it in PayPal.

```python
def mark_order_shipped(self,
                      slug,
                      order_id,
                      body)
```

## Authentication

This endpoint requires [AdminToken](../../doc/auth/custom-header-signature.md) **OR** [PlatformKey](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `slug` | `str` | Template, Required | The shop's link name (current or former). |
| `order_id` | `str` | Template, Required | OneThing's order id (`Order.id`). |
| `body` | [`ApiShopsOrdersShipRequest`](../../doc/models/api-shops-orders-ship-request.md) | Body, Required | - |

## Response Type

**200**: Shipped.

[`ApiShopsOrdersShipResponse`](../../doc/models/api-shops-orders-ship-response.md)

## Example Usage

```python
slug = 'raptorrush'

order_id = 'orderId2'

body = ApiShopsOrdersShipRequest(
    carrier=Carrier.DHL,
    tracking_number='trackingNumber4'
)

result = orders_api.mark_order_shipped(
    slug,
    order_id,
    body
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Something in the request needs fixing; `error` says what. | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | No such shop, or the admin token or API key doesn't match it. | [`ErrorException`](../../doc/models/error-exception.md) |


# List Webhook Events

The last 50 PayPal webhook deliveries about this shop's orders, with signature results.

```python
def list_webhook_events(self,
                       slug)
```

## Authentication

This endpoint requires [AdminToken](../../doc/auth/custom-header-signature.md) **OR** [PlatformKey](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `slug` | `str` | Template, Required | The shop's link name (current or former). |

## Response Type

**200**: Events, newest first.

[`List[WebhookEvent]`](../../doc/models/webhook-event.md)

## Example Usage

```python
slug = 'raptorrush'

result = orders_api.list_webhook_events(slug)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | No such shop, or the admin token or API key doesn't match it. | [`ErrorException`](../../doc/models/error-exception.md) |

