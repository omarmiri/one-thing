
# Status 2

## Enumeration

`Status2`

## Fields

| Name |
|  --- |
| `CREATED` |
| `PAID` |
| `FAILED` |

## Example

```python
from onethingapi.models.status_2 import Status2

status_2 = Status2.PAID
```

