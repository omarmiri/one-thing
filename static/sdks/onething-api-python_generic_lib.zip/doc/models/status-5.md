
# Status 5

## Enumeration

`Status5`

## Fields

| Name |
|  --- |
| `PENDING` |

## Example

```python
from onethingapi.models.status_5 import Status5

status_5 = Status5.PENDING
```

