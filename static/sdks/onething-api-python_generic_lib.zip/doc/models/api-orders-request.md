
# Api Orders Request

## Structure

`ApiOrdersRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `slug` | `str` | Required | - |

## Example

```python
from onethingapi.models.api_orders_request import ApiOrdersRequest

api_orders_request = ApiOrdersRequest(
    slug='slug0'
)
```

