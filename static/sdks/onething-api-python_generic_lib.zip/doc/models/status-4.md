
# Status 4

## Enumeration

`Status4`

## Fields

| Name |
|  --- |
| `CREATED` |
| `PAID` |
| `FAILED` |

## Example

```python
from onethingapi.models.status_4 import Status4

status_4 = Status4.FAILED
```

