
# Status 3

## Enumeration

`Status3`

## Fields

| Name |
|  --- |
| `CREATED` |
| `PAID` |
| `FAILED` |

## Example

```python
from onethingapi.models.status_3 import Status3

status_3 = Status3.FAILED
```

