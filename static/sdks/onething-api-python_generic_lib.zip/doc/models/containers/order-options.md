
# Order Options

## Data Type

`Dict[str, str]`

## Cases

| Type |
|  --- |
| `Dict[str, str]` |

## Dict[str, str]

### Initialization Code

#### Example

```python
value = {
    'Size': 'M',
    'Color': 'Black'
}
```

