
# Shop Option

Something the buyer picks, such as a size or a colour. The shop still sells one product.

## Structure

`ShopOption`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Required | **Constraints**: *Maximum Length*: `20` |
| `kind` | [`Kind`](../../doc/models/kind.md) | Required | `color` shows swatches, and the photo of the picked colour. |
| `values` | [`List[OptionValue]`](../../doc/models/option-value.md) | Required | **Constraints**: *Minimum Items*: `1`, *Maximum Items*: `12` |

## Example

```python
from onethingapi.models.kind import Kind
from onethingapi.models.option_value import OptionValue
from onethingapi.models.shop_option import ShopOption

shop_option = ShopOption(
    name='Size',
    kind=Kind.COLOR,
    values=[
        OptionValue(
            label='M',
            hex='#14171a',
            photo='photo6'
        )
    ]
)
```

