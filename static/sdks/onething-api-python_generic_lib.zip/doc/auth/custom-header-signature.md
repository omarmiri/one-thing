
# Custom Header Signature



Documentation for accessing and setting credentials for AdminToken.

## Auth Credentials

| Name | Type | Description | Getter |
|  --- | --- | --- | --- |
| x-admin-token | `str` | The shop's admin token, returned once by `createShop`. Keep it secret. | `x_admin_token` |



**Note:** Auth credentials can be set using `CustomHeaderAuthenticationCredentials` object, passed in as named parameter `custom_header_authentication_credentials` in the client initialization.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```python
from onethingapi.http.auth.custom_header_authentication import CustomHeaderAuthenticationCredentials
from onethingapi.onethingapi_client import OnethingapiClient

client = OnethingapiClient(
    custom_header_authentication_credentials=CustomHeaderAuthenticationCredentials(
        x_admin_token='x-admin-token'
    )
)
```


