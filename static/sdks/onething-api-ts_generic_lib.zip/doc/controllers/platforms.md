# Platforms

For marketplaces that make and run shops for their own sellers with one API key.

```ts
const platformsApi = new PlatformsApi(client);
```

## Class Name

`PlatformsApi`


# List My Shops

Every shop the API key's account owns, newest first, with what a catalog page needs: name, price, cover, link, whether PayPal is connected and how many sales it has.

```ts
async listMyShops(
  status?: Status,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ApiPlatformShopsResponse>>
```

## Authentication

This endpoint requires [PlatformKey](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`Status \| undefined`](../../doc/models/status.md) | Query, Optional | Only shops with this status, e.g. `live` for a public catalog. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: The shops.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ApiPlatformShopsResponse`](../../doc/models/api-platform-shops-response.md).

## Example Usage

```ts
try {
  const response = await platformsApi.listMyShops();

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof CustomError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | No API key, or it's wrong or revoked. | [`CustomError`](../../doc/models/custom-error.md) |

