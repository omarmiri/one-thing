
# Agent Shop Summary

## Structure

`AgentShopSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shop` | `string` | Required | The link name, for `getAgentProduct` and the MCP tools. |
| `name` | `string` | Required | - |
| `kind` | [`Kind1`](../../doc/models/kind-1.md) | Required | - |
| `headline` | `string` | Required | - |
| `price` | `string \| null` | Required | The price label, e.g. `$2.99`; null for recommendations. |
| `url` | `string` | Required | The shop page. |

## Example

```ts
import { AgentShopSummary, Kind1 } from 'one-thing-sdk';

const agentShopSummary: AgentShopSummary = {
  shop: 'shop8',
  name: 'name8',
  kind: Kind1.Physical,
  headline: 'headline2',
  price: 'price4',
  url: 'url2',
};
```

