
# Status 2

## Enumeration

`Status2`

## Fields

| Name |
|  --- |
| `Created` |
| `Paid` |
| `Failed` |

## Example

```ts
import { Status2 } from 'one-thing-sdk';

const status2 = Status2.Failed;
```

