
# Channel

`agent` for orders an AI agent placed through the MCP server.

## Enumeration

`Channel`

## Fields

| Name |
|  --- |
| `Web` |
| `Agent` |

## Example

```ts
import { Channel } from 'one-thing-sdk';

const channel = Channel.Web;
```

