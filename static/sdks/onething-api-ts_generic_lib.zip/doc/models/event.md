
# Event

## Enumeration

`Event`

## Fields

| Name |
|  --- |
| `EnumOrderpaid` |
| `EnumOrdershipped` |

## Example

```ts
import { Event } from 'one-thing-sdk';

const event = Event.EnumOrderpaid;
```

