
# Status 5

## Enumeration

`Status5`

## Fields

| Name |
|  --- |
| `Pending` |

## Example

```ts
import { Status5 } from 'one-thing-sdk';

const status5 = Status5.Pending;
```

