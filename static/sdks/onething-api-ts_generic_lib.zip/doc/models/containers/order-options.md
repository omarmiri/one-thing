
# Order Options

## Class Name

`OrderOptions`

## Cases

| Type |
|  --- |
| `Record<string, string>` |

## Record<string, string>

### Initialization Code

#### Example

```ts
const value: OrderOptions = {
  'Size': 'M',
  'Color': 'Black'
};
```

