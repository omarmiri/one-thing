
# Agent Product

A live shop as an AI agent sees it. Recommendations have `offers`; everything else has `price` and is bought with `create_order`.

## Structure

`AgentProduct`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shop` | `string` | Required | The link name, which the MCP tools take as `shop`. |
| `url` | `string` | Required | - |
| `name` | `string` | Required | - |
| `kind` | [`Kind1`](../../doc/models/kind-1.md) | Required | - |
| `headline` | `string` | Required | - |
| `description` | `string` | Required | - |
| `highlights` | `string[]` | Required | - |
| `details` | [`Detail[]`](../../doc/models/detail.md) | Required | - |
| `faq` | [`Faq[]`](../../doc/models/faq.md) | Required | - |
| `images` | `string[]` | Required | - |
| `price` | [`AgentMoney \| undefined`](../../doc/models/agent-money.md) | Optional | - |
| `shipping` | [`AgentProductShipping \| null \| undefined`](../../doc/models/containers/agent-product-shipping.md) | Optional | This is a container for one-of cases. |
| `total` | [`AgentMoney \| undefined`](../../doc/models/agent-money.md) | Optional | - |
| `delivery` | `string \| undefined` | Optional | - |
| `availability` | `string \| undefined` | Optional | - |
| `options` | [`Option1[] \| undefined`](../../doc/models/option-1.md) | Optional | Pass one value per option to `create_order`. |
| `variants` | [`Variant[] \| undefined`](../../doc/models/variant.md) | Optional | - |
| `offers` | [`Offer1[] \| undefined`](../../doc/models/offer-1.md) | Optional | Recommendations only. Bought at the retailer. |
| `howToBuy` | `string` | Required | - |
| `mcpServer` | `string \| undefined` | Optional | The MCP server to order through (`getAgentProduct` only). |

## Example

```ts
import { AgentProduct, Kind1 } from 'one-thing-sdk';

const agentProduct: AgentProduct = {
  shop: 'shop2',
  url: 'url6',
  name: 'name2',
  kind: Kind1.Referral,
  headline: 'headline8',
  description: 'description2',
  highlights: [
    'highlights1'
  ],
  details: [
    {
      label: 'label0',
      value: 'value2',
    }
  ],
  faq: [
    {
      q: 'q0',
      a: 'a8',
    }
  ],
  images: [
    'images1',
    'images0'
  ],
  howToBuy: 'how_to_buy8',
  price: {
    amount: 150.74,
    currency: 'currency2',
    label: 'label2',
  },
  shipping: {
    amount: 194.54,
    currency: 'currency2',
    shipsTo: [
      'ships_to5',
      'ships_to6',
      'ships_to7'
    ],
  },
  total: {
    amount: 71.32,
    currency: 'currency0',
    label: 'label0',
  },
  delivery: 'Shipped. PayPal collects the buyer\'s address at checkout.',
  availability: 'in_stock',
};
```

