
# Status 3

## Enumeration

`Status3`

## Fields

| Name |
|  --- |
| `Created` |
| `Paid` |
| `Failed` |

## Example

```ts
import { Status3 } from 'one-thing-sdk';

const status3 = Status3.Paid;
```

