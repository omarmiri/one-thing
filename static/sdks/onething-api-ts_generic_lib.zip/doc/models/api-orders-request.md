
# Api Orders Request

## Structure

`ApiOrdersRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `slug` | `string` | Required | - |

## Example

```ts
import { ApiOrdersRequest } from 'one-thing-sdk';

const apiOrdersRequest: ApiOrdersRequest = {
  slug: 'slug4',
};
```

